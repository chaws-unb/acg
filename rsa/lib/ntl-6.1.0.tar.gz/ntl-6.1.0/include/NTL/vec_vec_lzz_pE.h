
#ifndef NTL_vec_vec_zz_pE__H
#define NTL_vec_vec_zz_pE__H

#include <NTL/vec_lzz_pE.h>

NTL_OPEN_NNS

typedef Vec< Vec<zz_pE> > vec_vec_zz_pE;

NTL_CLOSE_NNS

#endif
