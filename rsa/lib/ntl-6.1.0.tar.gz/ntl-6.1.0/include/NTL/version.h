
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "6.1.0"

#define NTL_MAJOR_VERSION  (6)
#define NTL_MINOR_VERSION  (1)
#define NTL_REVISION       (0)

#endif

