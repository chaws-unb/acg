
#ifndef NTL_vec_long__H
#define NTL_vec_long__H

#include <NTL/vector.h>

NTL_OPEN_NNS

typedef Vec<long> vec_long;

NTL_CLOSE_NNS

#endif
